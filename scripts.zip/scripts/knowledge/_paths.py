"""Resuelve la raíz del proyecto por marcador (CLAUDE.md), no por cwd: antes todos los
scripts usaban Path.cwd(), que depende del directorio desde el que se invoque el script
(roto si se llama con una ruta relativa desde otro directorio, p. ej. desde un subagente
o un hook con cwd distinto)."""

from pathlib import Path

_MARKER = "CLAUDE.md"


def find_root(start: Path | None = None) -> Path:
    here = (start or Path.cwd()).resolve()
    for candidate in (here, *here.parents):
        if (candidate / _MARKER).exists():
            return candidate
    return here  # sin marcador (p. ej. fixture de test): se mantiene el cwd como antes
