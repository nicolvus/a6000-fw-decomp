#!/usr/bin/env python3
"""Grafo de conocimiento verificable: entidades Function + relaciones CALLS/CORRECTS/SUPERSEDES.

Fuentes, ambas deterministas (sin inferencia de LLM):
  1. JSON de funciones con forma {binary, sha256, address_space, symbol_value, original_name,
     outgoing}: crea entidades Function y relaciones CALLS solo cuando el destino en
     'outgoing' coincide por nombre con otra entidad del MISMO binario (misma sha256).
     Si no hay coincidencia exacta, se descarta (no se inventan destinos).
  2. Markdown indexado (tabla nodes de index_docs.py): busca palabras clave de corrección
     escritas por los propios investigadores ('CORRECCIÓN', 'corrige', 'SUPERADO', 'supera')
     y, dentro de la misma sección, un enlace Markdown a otro documento o una referencia de
     sesión ('sesión N' / 'SN') que resuelva a un documento existente por nombre de archivo.

Cada relación conserva: owner_source (archivo que la genera; reindexar/eliminar ese archivo
regenera/elimina solo sus relaciones), source_path, rango de líneas, cita textual (evidence)
y un status del vocabulario controlado (VERIFICADO/PARCIAL/NO_VERIFICADO/INFERENCIA/
DESCARTADO/SUPERADO/CONFLICTO_PENDIENTE), tomado del propio texto si está presente,
NO_VERIFICADO por defecto en caso contrario.

Requiere haber corrido antes index_docs.py (usa sus tablas documents/nodes).
Uso: python3 scripts/knowledge/build_graph.py [--db RUTA]
"""

import argparse
import hashlib
import json
import re
import sqlite3
from pathlib import Path

from _paths import find_root

ROOT = find_root()
DEFAULT_DB = ROOT / ".knowledge-cache" / "knowledge.sqlite"
FUNCTION_JSON_GLOB = ["analysis/**/*.json"]

STATUS_VOCAB = [
    "CONFLICTO_PENDIENTE", "NO_VERIFICADO", "VERIFICADO", "PARCIAL",
    "INFERENCIA", "DESCARTADO", "SUPERADO",
]
CORRECTION_RE = re.compile(r"CORRECCI[OÓ]N|corrig(e|i[oó]|iendo)", re.IGNORECASE)
SUPERSEDE_RE = re.compile(r"superad[ao]|\bsupera\b", re.IGNORECASE)
MD_LINK_RE = re.compile(r"\[[^\]]*\]\(([^)\s]+\.md)[^)]*\)")
SESSION_REF_RE = re.compile(r"[sS]esi[oó]n\s+(\d+)|\bS(\d+)\b")

GRAPH_SCHEMA = """
CREATE TABLE IF NOT EXISTS entities (
    id TEXT PRIMARY KEY,
    kind TEXT NOT NULL,
    name TEXT,
    binary TEXT,
    binary_sha256 TEXT,
    address_space TEXT,
    address TEXT,
    owner_source TEXT NOT NULL,
    extra TEXT
);
CREATE TABLE IF NOT EXISTS relations (
    id TEXT PRIMARY KEY,
    src_id TEXT NOT NULL,
    dst_id TEXT NOT NULL,
    type TEXT NOT NULL,
    status TEXT NOT NULL,
    extraction_method TEXT NOT NULL,
    owner_source TEXT NOT NULL,
    source_path TEXT NOT NULL,
    line_start INTEGER,
    line_end INTEGER,
    evidence TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_relations_src ON relations(src_id);
CREATE INDEX IF NOT EXISTS idx_relations_dst ON relations(dst_id);
CREATE INDEX IF NOT EXISTS idx_relations_owner ON relations(owner_source);
CREATE INDEX IF NOT EXISTS idx_entities_owner ON entities(owner_source);
"""


def function_id(binary_sha256: str, address_space: str, symbol_value: str) -> str:
    raw = f"Function::{binary_sha256}::{address_space}::{symbol_value}"
    return hashlib.sha1(raw.encode("utf-8")).hexdigest()[:16]


def relation_id(src: str, dst: str, rel_type: str, source_path: str, line_start: int) -> str:
    raw = f"{src}::{dst}::{rel_type}::{source_path}::{line_start}"
    return hashlib.sha1(raw.encode("utf-8")).hexdigest()[:16]


def method_name(original_name: str) -> str | None:
    """'ns::Clase::metodo()' -> 'metodo'. None si no hay forma reconocible."""
    match = re.search(r"([A-Za-z_][A-Za-z0-9_]*)\s*\(", original_name)
    return match.group(1) if match else None


def qualified_name(original_name: str) -> str | None:
    """'ns::Clase::metodo()' -> 'ns::Clase::metodo' (conserva el calificador). None si no
    hay forma reconocible. Se usa para desambiguar cuando dos clases del mismo binario
    comparten el mismo nombre de método corto (ver bug reproducido: X::caller() llama a
    A::run() pero el nombre corto 'run' también existe en B::run(), del mismo binario)."""
    match = re.search(r"([A-Za-z_][A-Za-z0-9_:]*)\s*\(", original_name)
    return match.group(1) if match else None


def load_function_dossiers() -> list[tuple[str, list[dict]]]:
    """Localiza JSON con forma {binary, sha256, address_space, symbol_value, original_name,
    outgoing} bajo analysis/. No asume una ruta fija: filtra por forma, no por nombre de archivo."""
    found = []
    for pattern in FUNCTION_JSON_GLOB:
        for path in ROOT.glob(pattern):
            if "codex-logs" in path.parts:
                continue
            try:
                data = json.loads(path.read_text(encoding="utf-8", errors="replace"))
            except (json.JSONDecodeError, UnicodeDecodeError):
                continue
            if not isinstance(data, list):
                continue
            items = [d for d in data if isinstance(d, dict)
                     and {"binary", "sha256", "address_space", "symbol_value",
                          "original_name"} <= d.keys()]
            if items:
                found.append((str(path.relative_to(ROOT)), items))
    return found


def build_function_graph(conn: sqlite3.Connection) -> tuple[int, int]:
    n_entities = n_relations = 0
    dossiers = load_function_dossiers()
    existing_sources = {rel_path for rel_path, _ in dossiers}
    orphan_owners = {
        row[0] for row in conn.execute(
            "SELECT DISTINCT owner_source FROM entities WHERE kind = 'Function'"
        )
    } - existing_sources
    for owner in orphan_owners:
        conn.execute("DELETE FROM entities WHERE owner_source = ?", (owner,))
        conn.execute("DELETE FROM relations WHERE owner_source = ?", (owner,))

    for rel_path, items in dossiers:
        conn.execute("DELETE FROM entities WHERE owner_source = ?", (rel_path,))
        conn.execute("DELETE FROM relations WHERE owner_source = ?", (rel_path,))

        # Índice por nombre calificado completo (desambigua entre clases distintas del mismo
        # binario) y, aparte, un CONTEO por nombre corto: si el nombre corto no es único en
        # el binario, una coincidencia por nombre corto es ambigua y se descarta en vez de
        # apuntar arbitrariamente a "el último insertado" (ese era el bug reproducido).
        by_qualified_in_binary: dict[tuple[str, str], str] = {}
        by_short_in_binary: dict[tuple[str, str], list[str]] = {}
        rows = []
        for item in items:
            eid = function_id(item["sha256"], item["address_space"], item["symbol_value"])
            qualified = qualified_name(item["original_name"]) or item["original_name"]
            short = method_name(item["original_name"]) or item["original_name"]
            rows.append((eid, item, qualified, short))
            by_qualified_in_binary[(item["sha256"], qualified)] = eid
            by_short_in_binary.setdefault((item["sha256"], short), []).append(eid)

        for eid, item, _qualified, _short in rows:
            conn.execute(
                "INSERT INTO entities (id, kind, name, binary, binary_sha256, address_space, "
                "address, owner_source, extra) VALUES (?,?,?,?,?,?,?,?,?)",
                (eid, "Function", item["original_name"], item["binary"], item["sha256"],
                 item["address_space"], item["symbol_value"], rel_path,
                 json.dumps({"confidence": item.get("confidence")}, ensure_ascii=False)),
            )
            n_entities += 1
            for outgoing in item.get("outgoing", []) if isinstance(item.get("outgoing"), list) else []:
                sha = item["sha256"]
                target_qualified = qualified_name(outgoing)
                dst_id = by_qualified_in_binary.get((sha, target_qualified)) if target_qualified else None
                if not dst_id:
                    target_short = method_name(outgoing) or outgoing.split(" ")[0]
                    candidates = by_short_in_binary.get((sha, target_short), [])
                    if len(candidates) != 1:
                        continue  # ambiguo (0 o >1 coincidencias por nombre corto): se descarta
                    dst_id = candidates[0]
                if dst_id == eid:
                    continue
                rid = relation_id(eid, dst_id, "CALLS", rel_path, 0)
                conn.execute(
                    "INSERT OR REPLACE INTO relations (id, src_id, dst_id, type, status, "
                    "extraction_method, owner_source, source_path, line_start, line_end, "
                    "evidence) VALUES (?,?,?,?,?,?,?,?,?,?,?)",
                    (rid, eid, dst_id, "CALLS", "PARCIAL", "json:name_match_same_binary",
                     rel_path, rel_path, None, None,
                     f"{item['original_name']} -> {outgoing} (confidence: {item.get('confidence')})"),
                )
                n_relations += 1
    return n_entities, n_relations


def detect_status(line: str, window_text: str) -> str:
    """Busca primero en la LÍNEA del marcador (evita atribuir un status que en realidad
    pertenece a una oración vecina dentro de la ventana) y solo si no hay nada ahí, en
    la ventana completa."""
    for text in (line, window_text):
        for token in STATUS_VOCAB:
            if re.search(token, text, re.IGNORECASE):
                return token
    return "NO_VERIFICADO"


def resolve_md_link(doc_path: str, link: str) -> str | None:
    candidate = (ROOT / doc_path).parent / link
    try:
        resolved = candidate.resolve().relative_to(ROOT.resolve())
    except ValueError:
        return None
    return str(resolved) if (ROOT / resolved).exists() else None


WINDOW = 2  # líneas alrededor del marcador de corrección: evita relaciones por proximidad de sección

# Documentos derivados (generados por export_corrections.py u otros exportadores del propio
# grafo): citan "CORRECTS"/enlaces por diseño y contaminarían el grafo con relaciones
# autorreferenciales si se escanean como si fueran hallazgos originales de investigación.
GENERATED_DOCS = {"docs/CORRECTIONS.md", "docs/OPEN-QUESTIONS.md"}


def build_correction_graph(conn: sqlite3.Connection) -> int:
    n_relations = 0
    docs_by_path = {row[0] for row in conn.execute("SELECT id FROM documents")}
    docs_by_session: dict[str, list[str]] = {}
    for doc_id in docs_by_path:
        basename = Path(doc_id).name
        m = re.match(r"s(?:ession)?0*(\d+)[-._]", basename, re.IGNORECASE)
        if m:
            docs_by_session.setdefault(m.group(1), []).append(doc_id)

    doc_paths = [row[0] for row in conn.execute("SELECT id FROM documents")
                 if row[0] not in GENERATED_DOCS]
    existing = set(doc_paths) | GENERATED_DOCS  # no son huérfanos; se excluyen, no se borran
    orphan_owners = {
        row[0] for row in conn.execute(
            "SELECT DISTINCT owner_source FROM relations "
            "WHERE extraction_method LIKE 'markdown:keyword+link%'"
        )
    } - existing
    for owner in orphan_owners | GENERATED_DOCS:
        conn.execute("DELETE FROM relations WHERE owner_source = ?", (owner,))

    for doc_id in doc_paths:
        conn.execute(
            "DELETE FROM relations WHERE owner_source = ? AND extraction_method "
            "LIKE 'markdown:keyword+link%'", (doc_id,),
        )
        fpath = ROOT / doc_id
        if not fpath.exists():
            continue
        lines = fpath.read_text(encoding="utf-8", errors="replace").splitlines()

        for i, line in enumerate(lines):
            is_correction = CORRECTION_RE.search(line)
            is_supersede = SUPERSEDE_RE.search(line)
            if not is_correction and not is_supersede:
                continue
            rel_type = "SUPERSEDES" if is_supersede else "CORRECTS"
            lo, hi = max(0, i - WINDOW), min(len(lines), i + WINDOW + 1)
            window_text = "\n".join(lines[lo:hi])
            status = detect_status(line, window_text)

            # same_line: el enlace/referencia está en la MISMA oración que el marcador de
            # corrección -> relación con evidencia directa. window: el enlace solo aparece
            # en una línea vecina (±2) -> candidata, nunca se marca VERIFICADO aunque el
            # texto cercano use esa palabra (proximidad no es demostración).
            same_line_targets: set[str] = set()
            window_only_targets: set[str] = set()
            for link in MD_LINK_RE.findall(line):
                resolved = resolve_md_link(doc_id, link)
                if resolved and resolved != doc_id and resolved not in GENERATED_DOCS:
                    same_line_targets.add(resolved)
            for link in MD_LINK_RE.findall(window_text):
                resolved = resolve_md_link(doc_id, link)
                if resolved and resolved != doc_id and resolved not in GENERATED_DOCS:
                    window_only_targets.add(resolved)
            window_only_targets -= same_line_targets
            for m in SESSION_REF_RE.finditer(line):  # solo la línea del marcador: el encabezado
                                                       # de sección (en la ventana) no es el objetivo
                num = m.group(1) or m.group(2)
                candidates = docs_by_session.get(num, [])
                if len(candidates) <= 2:  # ambigüedad baja; si hay más, no se puede resolver sin adivinar
                    for candidate_doc in candidates:
                        if candidate_doc != doc_id:
                            same_line_targets.add(candidate_doc)

            for target, method, row_status in (
                [(t, "markdown:keyword+link_or_session_same_line", status)
                 for t in same_line_targets]
                + [(t, "markdown:keyword+link_window_candidate", "CONFLICTO_PENDIENTE")
                   for t in window_only_targets]
            ):
                line_no = i + 1
                rid = relation_id(doc_id, target, rel_type, doc_id, line_no)
                conn.execute(
                    "INSERT OR REPLACE INTO relations (id, src_id, dst_id, type, status, "
                    "extraction_method, owner_source, source_path, line_start, line_end, "
                    "evidence) VALUES (?,?,?,?,?,?,?,?,?,?,?)",
                    (rid, doc_id, target, rel_type, row_status, method,
                     doc_id, doc_id, line_no, line_no, window_text[:400]),
                )
                n_relations += 1
    return n_relations


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--db", default=str(DEFAULT_DB))
    args = ap.parse_args()

    conn = sqlite3.connect(args.db)
    conn.executescript(GRAPH_SCHEMA)
    if conn.execute("SELECT COUNT(*) FROM documents").fetchone()[0] == 0:
        raise SystemExit("La tabla documents está vacía. Ejecuta primero index_docs.py")

    n_func_entities, n_func_relations = build_function_graph(conn)
    n_corr_relations = build_correction_graph(conn)
    conn.commit()

    total_entities = conn.execute("SELECT COUNT(*) FROM entities").fetchone()[0]
    total_relations = conn.execute("SELECT COUNT(*) FROM relations").fetchone()[0]
    conn.close()
    print(f"Funciones: {n_func_entities} entidades, {n_func_relations} relaciones CALLS.")
    print(f"Correcciones: {n_corr_relations} relaciones CORRECTS/SUPERSEDES.")
    print(f"Total grafo: {total_entities} entidades, {total_relations} relaciones. DB: {args.db}")


if __name__ == "__main__":
    main()
