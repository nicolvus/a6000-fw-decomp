"""Regresión del grafo: entidades Function desde JSON, correcciones desde Markdown,
y el caso límite de proximidad (el número de sesión del encabezado no debe colarse
como objetivo de una corrección que menciona OTRA sesión en el cuerpo)."""

import json
import sqlite3
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
INDEX_SCRIPT = ROOT / "scripts" / "knowledge" / "index_docs.py"
GRAPH_SCRIPT = ROOT / "scripts" / "knowledge" / "build_graph.py"


class BuildGraphTest(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.tmp_path = Path(self._tmp.name)
        self.proj = self.tmp_path / "proj"
        (self.proj / "docs" / "capture").mkdir(parents=True)
        (self.proj / "analysis" / "functions").mkdir(parents=True)
        self.db = self.tmp_path / "knowledge.sqlite"

    def tearDown(self):
        self._tmp.cleanup()

    def run_script(self, script):
        return subprocess.run(
            [sys.executable, str(script), "--db", str(self.db)],
            cwd=self.proj, check=True, capture_output=True, text=True,
        )

    def test_function_calls_require_exact_name_match_same_binary(self):
        dossier = [
            {"binary": "lib/a.so", "sha256": "abc", "address_space": "ELF",
             "symbol_value": "0x100", "original_name": "ns::A::foo()",
             "outgoing": ["bar at 0x200", "unresolved external call"]},
            {"binary": "lib/a.so", "sha256": "abc", "address_space": "ELF",
             "symbol_value": "0x200", "original_name": "ns::B::bar()",
             "outgoing": []},
            {"binary": "lib/other.so", "sha256": "xyz", "address_space": "ELF",
             "symbol_value": "0x200", "original_name": "ns::C::bar()",
             "outgoing": []},
        ]
        (self.proj / "analysis" / "functions" / "dossier.json").write_text(
            json.dumps(dossier), encoding="utf-8"
        )
        (self.proj / "docs" / "capture" / "placeholder.md").write_text("# Placeholder\n")
        self.run_script(INDEX_SCRIPT)
        self.run_script(GRAPH_SCRIPT)

        conn = sqlite3.connect(self.db)
        self.assertEqual(conn.execute("SELECT COUNT(*) FROM entities").fetchone()[0], 3)
        rels = conn.execute("SELECT type, src_id, dst_id FROM relations WHERE type='CALLS'").fetchall()
        self.assertEqual(len(rels), 1)  # solo foo->bar en el MISMO binario; ns::C::bar() se descarta
        conn.close()

    def test_ambiguous_short_name_in_same_binary_is_discarded_not_misrouted(self):
        # Caso reproducido en la auditoría: X::caller() llama a A::run(), pero B::run()
        # (otra clase, MISMO binario) tiene el mismo nombre corto "run". Antes, el índice
        # por nombre corto se sobrescribía (el último insertado "ganaba"), así que el grafo
        # podía registrar X::caller() -> B::run() en vez de -> A::run(), o al revés según
        # el orden de inserción. Ahora: si el nombre corto es ambiguo en el binario y la
        # llamada no trae el nombre calificado, no se genera ninguna arista (ni A ni B).
        dossier = [
            {"binary": "lib/a.so", "sha256": "abc", "address_space": "ELF",
             "symbol_value": "0x100", "original_name": "ns::X::caller()",
             "outgoing": ["run()"]},  # llamada SIN calificar: ambigua entre A::run y B::run
            {"binary": "lib/a.so", "sha256": "abc", "address_space": "ELF",
             "symbol_value": "0x200", "original_name": "ns::A::run()", "outgoing": []},
            {"binary": "lib/a.so", "sha256": "abc", "address_space": "ELF",
             "symbol_value": "0x300", "original_name": "ns::B::run()", "outgoing": []},
        ]
        (self.proj / "analysis" / "functions" / "dossier.json").write_text(
            json.dumps(dossier), encoding="utf-8"
        )
        (self.proj / "docs" / "capture" / "placeholder.md").write_text("# Placeholder\n")
        self.run_script(INDEX_SCRIPT)
        self.run_script(GRAPH_SCRIPT)

        conn = sqlite3.connect(self.db)
        rels = conn.execute("SELECT type FROM relations WHERE type='CALLS'").fetchall()
        conn.close()
        self.assertEqual(len(rels), 0)  # ambiguo: ninguna arista, nunca una incorrecta

    def test_qualified_outgoing_name_disambiguates_same_short_name(self):
        # Mismo caso, pero la llamada SÍ trae el nombre calificado ("ns::A::run()"):
        # debe resolver exactamente a A::run, nunca a B::run.
        dossier = [
            {"binary": "lib/a.so", "sha256": "abc", "address_space": "ELF",
             "symbol_value": "0x100", "original_name": "ns::X::caller()",
             "outgoing": ["ns::A::run()"]},
            {"binary": "lib/a.so", "sha256": "abc", "address_space": "ELF",
             "symbol_value": "0x200", "original_name": "ns::A::run()", "outgoing": []},
            {"binary": "lib/a.so", "sha256": "abc", "address_space": "ELF",
             "symbol_value": "0x300", "original_name": "ns::B::run()", "outgoing": []},
        ]
        (self.proj / "analysis" / "functions" / "dossier.json").write_text(
            json.dumps(dossier), encoding="utf-8"
        )
        (self.proj / "docs" / "capture" / "placeholder.md").write_text("# Placeholder\n")
        self.run_script(INDEX_SCRIPT)
        self.run_script(GRAPH_SCRIPT)

        conn = sqlite3.connect(self.db)
        rels = conn.execute(
            "SELECT src_id, dst_id FROM relations WHERE type='CALLS'"
        ).fetchall()
        conn.close()
        self.assertEqual(len(rels), 1)
        src, dst = rels[0]
        with sqlite3.connect(self.db) as c:
            caller_id = c.execute(
                "SELECT id FROM entities WHERE name = 'ns::X::caller()'"
            ).fetchone()[0]
            a_run_id = c.execute(
                "SELECT id FROM entities WHERE name = 'ns::A::run()'"
            ).fetchone()[0]
        self.assertEqual(src, caller_id)
        self.assertEqual(dst, a_run_id)

    def test_correction_resolves_only_from_same_line_not_section_window(self):
        # El encabezado menciona "S21"; el cuerpo corrige "S18" en una línea distinta.
        # Con solo un documento s18 existente, debe resolver a S18 y NO inventar un
        # destino a partir del número de sesión del propio encabezado.
        (self.proj / "docs" / "capture" / "s18-topic.md").write_text("# S18 — tema\n\ncontenido\n")
        (self.proj / "docs" / "capture" / "s21-topic.md").write_text(
            "## S21 — otro tema\n\n"
            "Línea de relleno.\n"
            "Línea de relleno.\n"
            "**VERIFICADO (corrige S18):** el resultado anterior era incompleto.\n"
        )
        self.run_script(INDEX_SCRIPT)
        self.run_script(GRAPH_SCRIPT)

        conn = sqlite3.connect(self.db)
        rels = conn.execute(
            "SELECT status, dst_id FROM relations WHERE src_id = 'docs/capture/s21-topic.md'"
        ).fetchall()
        conn.close()
        self.assertEqual(len(rels), 1)
        status, dst = rels[0]
        self.assertEqual(dst, "docs/capture/s18-topic.md")
        self.assertEqual(status, "VERIFICADO")

    def test_link_only_in_window_is_candidate_not_verified(self):
        # El enlace a old.md está en la línea SIGUIENTE a la del marcador "CORRECCIÓN",
        # no en la misma oración: es una relación candidata (proximidad), no demostrada.
        # Antes se le asignaba igualmente el status VERIFICADO si esa palabra aparecía en
        # la ventana; ahora una relación solo de ventana se marca CONFLICTO_PENDIENTE.
        (self.proj / "docs" / "capture" / "old.md").write_text("# Resultado original\n\ncontenido\n")
        (self.proj / "docs" / "capture" / "new.md").write_text(
            "# Resultado nuevo\n\n"
            "CORRECCIÓN VERIFICADA: el resultado cambió.\n"
            "Ver también [el resultado anterior](old.md) para contexto.\n"
        )
        self.run_script(INDEX_SCRIPT)
        self.run_script(GRAPH_SCRIPT)

        conn = sqlite3.connect(self.db)
        rows = conn.execute(
            "SELECT status, extraction_method FROM relations WHERE dst_id = 'docs/capture/old.md'"
        ).fetchall()
        conn.close()
        self.assertEqual(len(rows), 1)
        status, method = rows[0]
        self.assertEqual(status, "CONFLICTO_PENDIENTE")
        self.assertIn("window_candidate", method)

    def test_md_link_correction_and_claim_query(self):
        (self.proj / "docs" / "capture" / "old.md").write_text("# Resultado original\n\ncontenido\n")
        (self.proj / "docs" / "capture" / "new.md").write_text(
            "# Resultado nuevo\n\n"
            "CORRECCIÓN: esto corrige [el resultado anterior](old.md) con nueva evidencia.\n"
        )
        self.run_script(INDEX_SCRIPT)
        self.run_script(GRAPH_SCRIPT)

        conn = sqlite3.connect(self.db)
        incoming = conn.execute(
            "SELECT type, src_id, evidence FROM relations WHERE dst_id = 'docs/capture/old.md'"
        ).fetchall()
        conn.close()
        self.assertEqual(len(incoming), 1)
        rel_type, src, evidence = incoming[0]
        self.assertEqual(rel_type, "CORRECTS")
        self.assertEqual(src, "docs/capture/new.md")
        self.assertIn("corrige", evidence)

    def test_removing_owner_doc_prunes_its_relations_on_rebuild(self):
        (self.proj / "docs" / "capture" / "old.md").write_text("# Resultado original\n\ncontenido\n")
        (self.proj / "docs" / "capture" / "new.md").write_text(
            "# Resultado nuevo\n\nCORRECCIÓN: corrige [lo anterior](old.md).\n"
        )
        self.run_script(INDEX_SCRIPT)
        self.run_script(GRAPH_SCRIPT)
        (self.proj / "docs" / "capture" / "new.md").unlink()
        self.run_script(INDEX_SCRIPT)
        self.run_script(GRAPH_SCRIPT)

        conn = sqlite3.connect(self.db)
        remaining = conn.execute(
            "SELECT COUNT(*) FROM relations WHERE owner_source = 'docs/capture/new.md'"
        ).fetchone()[0]
        conn.close()
        self.assertEqual(remaining, 0)


if __name__ == "__main__":
    unittest.main()
