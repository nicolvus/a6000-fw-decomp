# Progreso — sistema de conocimiento Sony A6000

Checkpoint persistente. Actualizar al terminar cada etapa, antes de continuar
con la siguiente. No reescribir historial: añadir entradas nuevas.

## Fases (ver plan completo en el mensaje del usuario, 2026-10-18)

| # | Fase | Estado |
|---|------|--------|
| 1 | Validar/mejorar indexación FTS5 existente | COMPLETA |
| 2 | Indexación jerárquica (estilo PageIndex, sin dependencia) | COMPLETA |
| 3 | Grafo de conocimiento en SQLite | COMPLETA |
| 4 | Reconciliación de hallazgos (S19–S30, Darwin, EFCS, GPIO, WriteStill) | COMPLETA |
| 5 | Recuperación adaptativa (router de métodos) | COMPLETA |
| 6 | CLI unificada + servidor MCP | COMPLETA |
| 7 | Skills compartidas Claude/Codex | COMPLETA (ver caveat de verificación) |
| 8 | Memoria persistente / checkpoints de sesión | COMPLETA |
| 9 | Benchmarks reproducibles | COMPLETA |
| 10 | Validación final | COMPLETA |

## Archivos creados hasta ahora

- `scripts/knowledge/index_docs.py` — indexador incremental SHA-256 → SQLite FTS5
  + tablas jerárquicas `documents`/`nodes` (Repositorio→Subsistema→Documento→Sección).
  IDs estables = sha1(path::heading::occurrence)[:16]; no dependen del orden global.
- `scripts/knowledge/search.py` — CLI: `exact` (ripgrep), `text` (BM25),
  `tree` (navega subsistema/documento/sección sin cargar cuerpo),
  `section` (recupera texto original por rango de líneas, sin duplicar contenido en la DB).
- `tests/knowledge/test_index_docs.py` — 4 tests unittest, verdes (roundtrip, incremental,
  poda de borrados, jerarquía+recuperación exacta).
- `.knowledge-cache/knowledge.sqlite` — DB regenerable (gitignorada): 355 documentos,
  2684 secciones/nodos, 32 subsistemas (derivados de los 2 primeros componentes de ruta).
- `.venv/` + `knowledge/requirements-dev.txt` — entorno aislado con ruff/mypy/pytest.

## Fase 3 — Grafo de conocimiento (detalle)

- `scripts/knowledge/build_graph.py` — añade tablas `entities`/`relations` a la MISMA DB
  (no hay sistema paralelo). Dos fuentes, ambas deterministas:
  1. **Function/CALLS** desde JSON con forma `{binary, sha256, address_space, symbol_value,
     original_name, outgoing}` (detectado por forma, no por ruta fija). Una relación CALLS
     solo se crea si el nombre del destino en `outgoing` coincide EXACTAMENTE con el nombre
     de otra entidad del MISMO binario (misma sha256); si no hay coincidencia exacta se
     descarta (no se inventan destinos). Con los 3 dossiers reales: 3 entidades, 1 relación.
  2. **CORRECTS/SUPERSEDES** desde Markdown: busca palabras clave que los propios
     investigadores ya escribieron (CORRECCIÓN/corrige, superad[ao]/supera) línea por línea
     (no por sección completa — una sección larga como el índice del README NO genera
     relaciones falsas solo por contener la palabra en otro punto). El objetivo se resuelve
     por: (a) enlace Markdown en una ventana de ±2 líneas alrededor del marcador, o
     (b) referencia de sesión (`sesión N`/`SN`) en la MISMA línea del marcador (no en la
     ventana: el número de sesión del encabezado de la propia sección no debe colarse como
     objetivo — bug real detectado y corregido con test de regresión). Si una referencia de
     sesión es ambigua (más de 2 documentos candidatos), se descarta en vez de adivinar.
  - Cada relación guarda: `owner_source` (archivo que la genera; al reindexar/eliminar ese
    archivo se regeneran/eliminan solo sus relaciones, incluyendo huérfanos de archivos ya
    borrados), `source_path`, rango de líneas, `status` (del vocabulario controlado,
    detectado en el texto si está presente, `NO_VERIFICADO` por defecto) y `evidence`
    (cita textual literal).
  - Con los datos reales: 31 relaciones CORRECTS/SUPERSEDES (antes de la corrección del
    bug de ventana: 410 — la mayoría falsos positivos por proximidad de sección completa).
- `scripts/knowledge/search.py` gana `graph` (relaciones entrantes/salientes de un doc,
  con evidencia) y `claim` (conclusión vigente de un documento: qué lo corrige/supera).
  Verificado con consultas reales del plan: "¿qué corrigió S28?" → S23/S25 con cita exacta;
  conclusión vigente de S27 → corregido por README y superado según CONTEXT.md.
- `tests/knowledge/test_build_graph.py` — 4 tests: filtrado CALLS por nombre+binario exacto,
  no-confusión encabezado-vs-cuerpo en referencias de sesión, resolución por enlace Markdown
  + consulta de conclusión vigente, y poda de relaciones al eliminar el documento que las originó.

## Fase 4 — Reconciliación (detalle, PARCIAL)

Hecho y verificado:
- Respaldo íntegro de `CONTEXT.md`: `docs/history/CONTEXT.md.2026-10-18.bak` +
  `docs/history/CONTEXT.md.sha256.orig`. Verificado con `sha256sum -c --strict` → OK,
  y `diff` contra el original → idéntico.
- `scripts/knowledge/export_corrections.py` (nuevo): genera `docs/CORRECTIONS.md` (31 filas,
  derivado de `relations` tipo CORRECTS/SUPERSEDES) y `docs/OPEN-QUESTIONS.md` (382 filas,
  secciones con marcador NO_VERIFICADO/CONFLICTO_PENDIENTE vía FTS5). Documentos regenerables,
  marcados "no editar a mano". Test de regresión: `test_export_corrections.py` (1 test), verde.
- `docs/STATE.md` (nuevo): estado breve con enlaces a fuentes canónicas ya existentes
  (no reinterpreta nada, solo cita y enlaza): corrección Darwin base ROM 0x4200,
  SetImageWrited 0x1007 (no 0x1009), mapeo GPIO P4D/P4E/P4C/P4B, EFCS→IMX210, y la tabla
  de flujos completos/incompletos de `docs/estado-y-viabilidad-2026-10-17.md`.

Completado también:
- `CONTEXT.md` reducido de 1263 a 116 líneas: conserva verbatim solo S28–S30 (investigación
  activa) + punteros a `docs/STATE.md`, `docs/CORRECTIONS.md`, `docs/OPEN-QUESTIONS.md` y al
  historial íntegro. **Verificación de integridad:** `sha256sum` de
  `docs/history/CONTEXT-full-2026-10-18.md` (copia legible íntegra) coincide EXACTAMENTE
  con el hash original pre-edición (`5bd41bb4...`) — ningún contenido se perdió, solo se
  reubicó. El `.bak` binario-idéntico se conserva aparte.
- **Bug de auto-contaminación detectado y corregido:** al reindexar el propio
  `docs/CORRECTIONS.md` (que por diseño contiene la palabra "CORRECTS" y decenas de enlaces),
  el grafo generaba 121 relaciones circulares a partir de su propio export. Corregido
  excluyendo `docs/CORRECTIONS.md`/`docs/OPEN-QUESTIONS.md` de la extracción como fuentes
  primarias (`GENERATED_DOCS` en `build_graph.py`), con test de regresión que verifica
  reconstrucción estable (idempotente) tras reindexar los documentos generados.
- Total final estable tras dos pasadas consecutivas: 39 relaciones CORRECTS/SUPERSEDES,
  3 entidades Function, 1 CALLS. `docs/CORRECTIONS.md` y `docs/OPEN-QUESTIONS.md` regenerados.

No hecho (límite de alcance, no omisión):
- No se añadieron extractores para los JSON con esquema distinto al de `dossiers.json`
  (ver límite documentado en Fase 3): GPIO/IMX210/REA no están en el grafo todavía.

## Fase 5 — Recuperación adaptativa (detalle)

- `search.py ask <consulta> [--budget N]` (nuevo): clasifica la consulta con
  `classify_query` — `identifier` (dirección hex o símbolo sin espacios) → `exact`;
  `doc` (ruta `.md`) → relaciones entrantes (`claim`) + árbol (`tree`); `concept`
  (texto libre) → BM25 (`text`) + correcciones relacionadas de cada resultado vía grafo.
  Deduplica por `(ruta, línea)`, recorta por presupuesto de caracteres configurable
  (`--budget`, por defecto 2000) e informa cuántos resultados se mostraron vs. el total.
- Robustez corregida: `ask` ahora degrada sin fallar si `build_graph.py` no se ha
  ejecutado todavía (tabla `relations` ausente) — bug real encontrado por el test
  de regresión al indexar sin construir el grafo primero.
- `tests/knowledge/test_adaptive_search.py` (nuevo, 5 tests): clasificación de los
  3 tipos de consulta + recorte por presupuesto con aviso de truncado.
- Verificado con consultas reales: `ask "0x932a44"` (identifier), `ask
  "docs/capture/s27-effect-postprocess-rewire.md"` (doc), `ask "Darwin base ROM"`
  (concept, con corrección relacionada vía grafo incluida automáticamente).
- Total suite tras esta fase: 15/15 tests, ruff/mypy sin avisos.

## Fase 6 — CLI unificada + servidor MCP (detalle)

- CLI unificada: `search.py` ya cubre exact/text/tree/section/graph/claim/ask (fase 5);
  no se creó un entrypoint adicional porque multiplicaría comandos sin necesidad
  (`index_docs.py`/`build_graph.py`/`export_corrections.py` son operaciones de
  mantenimiento separadas a propósito, ejecutadas explícitamente, nunca disparadas
  desde una búsqueda de solo lectura).
- `scripts/knowledge/mcp_server.py` (nuevo): servidor MCP de solo lectura con el SDK
  oficial `mcp==2.3.0` (API `MCPServer`, antes `FastMCP` en mcp 1.x — instalado en
  `.venv/`, versión fijada en `knowledge/requirements.txt`). **No reimplementa lógica**:
  cada tool captura la salida de la función `cmd_*` correspondiente de `search.py` vía
  `contextlib.redirect_stdout` — una sola fuente de verdad para CLI y MCP.
  9 tools: `search_exact`, `search_documents`, `search_hybrid`, `find_symbol`,
  `get_document_section`, `query_graph`, `find_corrections`, `get_open_questions`,
  `get_current_state` — exactamente las operaciones mínimas pedidas, sin duplicar.
- **Verificado de verdad, no solo importado:**
  - `tests/knowledge/test_mcp_server.py` (4 tests) usa el servidor real en memoria:
    `list_tools()` confirma que las 9 herramientas se descubren vía protocolo MCP;
    `call_tool("search_exact", ...)` y `call_tool("get_current_state", ...)` devuelven
    datos reales del repositorio; una llamada con parámetro fuera de rango
    (`direction="sideways"`) no tira el servidor.
  - Arranque real por stdio: `python3 scripts/knowledge/mcp_server.py < /dev/null`
    sale con código 0 y sin stderr (smoke test de inicialización del transporte).
- Integración de clientes:
  - **Claude Code:** `.mcp.json` en la raíz del proyecto (nuevo), apunta al Python del
    venv del proyecto — no se tocó ninguna configuración MCP previa (no existía ninguna).
  - **Codex:** su configuración MCP vive en `~/.codex/config.toml` (fuera del proyecto,
    global del usuario); no se modificó un archivo global sin instrucción explícita.
    Snippet exacto para que el usuario lo añada si quiere usar el mismo servidor desde Codex:
    ```toml
    [mcp_servers.sony-a6000-knowledge]
    command = "/home/nicolas/Documents/a6000/sony-a6000-electronic-shutter/.venv/bin/python3"
    args = ["/home/nicolas/Documents/a6000/sony-a6000-electronic-shutter/scripts/knowledge/mcp_server.py"]
    ```
- Total suite tras esta fase: 19/19 tests, ruff/mypy sin avisos.

## Fase 7 — Skills compartidas (detalle)

- Fuente canónica única: `.claude/skills/{knowledge-navigation,contradiction-audit,
  knowledge-maintenance,session-checkpoint}/SKILL.md`. `.agents/skills/*` son enlaces
  simbólicos relativos a esa fuente (`ln -s ../../.claude/skills/<nombre> ...`),
  confirmado que no son copias divergentes: `readlink -f` de cada uno resuelve al
  archivo canónico real.
- Solo 4 skills, no las ~10 que enumera el plan original: se consolidaron
  `firmware-evidence`+`context-retrieval` dentro de `knowledge-navigation` y
  `graph-navigation` dentro de `contradiction-audit` porque todas invocan los
  mismos 2-3 scripts (`search.py`, `build_graph.py`) — crear una skill por
  subcomando de CLI habría sido redundante sin aportar procedimiento distinto.
  NO se crearon `firmware-comparison` ni `retrieval-benchmark`: no existe todavía
  una herramienta de comparación de firmware ni un harness de benchmarks que
  esas skills pudieran describir honestamente (ver Fase 9 pendiente).
- `CLAUDE.md` y `AGENTS.md` de proyecto (nuevos, no existían): breves, solo
  apuntan a las skills y a `knowledge/PROGRESS.md`/`docs/STATE.md`, sin duplicar
  contenido técnico.
- Validación estática de las 8 rutas (4 canónicas + 4 symlinks): frontmatter
  `name`/`description` presente y bien formado en todas — verificado con un
  parser real, no solo "se ve bien".
- **Caveat honesto de verificación:** no se pudo confirmar el descubrimiento EN
  CALIENTE por un Claude Code o Codex reales, porque esta misma sesión ya había
  cargado su listado de skills antes de que estos archivos existieran, y no hay
  forma de reiniciar la sesión desde aquí para re-listarlas; tampoco hay un
  binario de Codex disponible en este entorno para lanzarlo. Queda pendiente que
  el usuario confirme en una sesión nueva que `/knowledge-navigation` (u otro
  nombre de invocación de su cliente) aparece en el listado.

## Fase 8 — Memoria persistente / checkpoints (detalle)

- `scripts/knowledge/checkpoint.py` (nuevo): checkpoints estructurados JSON en
  `knowledge/checkpoints/` (directorio ya existía, vacío desde la Fase 1). Campos
  obligatorios según el plan: goal, done, files, findings, evidence, corrections,
  tests, blockers, next_actions, permissions_state. Nunca se edita el JSON a mano:
  se crea con flags de CLI (`create --goal ... --done ... --file ... ...`).
- `list`/`latest`/`show <id>` para leer sin tener que abrir archivos JSON directamente.
- **Bug real encontrado y corregido:** el timestamp inicial tenía resolución de
  segundo; dos checkpoints creados en el mismo segundo se ordenaban por el sufijo
  UUID aleatorio en vez de por orden de creación, así que `latest` podía devolver
  el equivocado. Corregido con microsegundos en el timestamp; test de regresión
  (`test_list_and_latest_reflect_created_checkpoint`) que crea dos seguidos y
  verifica el orden.
- `tests/knowledge/test_checkpoint.py` (3 tests: campos completos, list/latest,
  show por id parcial). Total suite: 22/22, ruff/mypy sin avisos.
- Primer checkpoint real creado: `knowledge/checkpoints/2026-10-18T05-10-01-412803Z-fe6147e3.json`,
  cubre las fases 1-8 de esta misma sesión con hallazgos, archivos, tests y bloqueos reales.

## Fase 9 — Benchmarks (detalle)

- `scripts/knowledge/benchmark.py` (nuevo): 7 consultas de referencia reales
  (SetImageWrited por dirección y por código corregido, GPIO cortinillas, EFCS,
  Darwin base ROM, comparación A6300, corrección de S27), cada una con una
  verdad de referencia fijada MANUALMENTE antes de ejecutar el script (ver
  campo `note` por consulta) — nunca "lo que el propio sistema devolvió".
  Compara ripgrep crudo sobre todo el repo vs `search.py text`(FTS5)/`exact` vs
  `ask` (adaptativo), midiendo latencia real, líneas, caracteres y una
  estimación de tokens (caracteres/4, marcada explícitamente como aproximación:
  no hay tokenizador real en este entorno). Salida regenerable:
  `knowledge/benchmarks/report.md` + `.json`.
- **Bug real encontrado y corregido durante la propia ejecución:** 2 de 21
  comparaciones daban "fallo" porque el snippet BM25 resalta coincidencias
  insertando `[corchetes]` DENTRO del token (`1ST_[CURTAIN]_MG`), rompiendo la
  subcadena esperada (`1st_curtain_mg`). El sistema sí encontraba el documento
  correcto (verificado manualmente); el defecto estaba en el criterio de acierto
  del benchmark, no en la recuperación. Corregido quitando `[`/`]` antes de
  comparar. Resultado final real: **21/21 aciertos**.
- Resultado honesto más relevante (sin inventar porcentajes): para consultas
  conceptuales, ripgrep crudo sobre todo el repo devuelve decenas de MB (p. ej.
  "darwin-rom-base": 191.760.545 caracteres, ~47.9M tokens estimados) porque
  coincide con logs de sesiones de cientos de miles de líneas; `search.py text`
  (FTS5) y `ask` devuelven ~2-3 KB (~250-670 tokens estimados) para la MISMA
  consulta, con el documento correcto entre los primeros resultados. La
  reducción es una consecuencia medida de indexar por sección en vez de grepear
  archivos completos, no una optimización ad-hoc para la demo.
- `tests/knowledge/test_benchmark.py` (1 test, verifica estructura del reporte
  con un corpus de prueba pequeño, no valores absolutos que dependen de la
  máquina). Total suite: 23/23, ruff/mypy sin avisos.

## Fase 10 — Validación final (detalle)

Ejecutado en una sola pasada, 18-10-2026:
1. Reconstrucción completa desde cero (`rm .knowledge-cache/knowledge.sqlite` +
   index→graph→export→reindex→rebuild): 359 archivos, 2697 secciones, 3 entidades,
   40 relaciones — estable, mismos totales que ejecuciones anteriores.
2. `pytest tests/knowledge -q`: 23/23 passed.
3. `ruff check scripts/knowledge tests/knowledge` + `mypy --ignore-missing-imports`:
   sin avisos.
4. `python3 scripts/knowledge/mcp_server.py < /dev/null`: exit=0, sin stderr
   (arranque real por stdio).
5. Integridad de `CONTEXT.md`: `sha256sum docs/history/CONTEXT-full-2026-10-18.md`
   == hash original pre-edición (`5bd41bb4...`) — confirmado de nuevo, no solo
   en la Fase 4.
6. `firmware/` y `analysis/ghidra/*.gpr` listados (no leídos/modificados):
   estructura intacta, ningún archivo binario tocado por este trabajo.
7. Sin repositorio `.git` en el proyecto: no hubo riesgo de commit/push accidental;
   ninguna operación de git se ejecutó en ninguna fase.

## Entorno de desarrollo

- `.venv/` creado en la raíz del proyecto (autorizado por el usuario, aislado, sin sudo).
- Versiones fijadas en `knowledge/requirements-dev.txt`: ruff 0.17.1, mypy 2.4.0, pytest 9.1.1.
- Activar con `source .venv/bin/activate` antes de `ruff check` / `mypy` / `pytest`.

## Pruebas ejecutadas

- `python3 -m unittest tests.knowledge.test_index_docs` → OK (3/3), 2026-10-18.
- Búsqueda exacta sobre `0x4383fd6c` y `SetImageWrited`: resultados correctos,
  incluida la corrección S12 (`0x1007` no `0x1009`).
- Búsqueda textual BM25 sobre "SilentShutter EFCS" y "Darwin base ROM": resultados pertinentes.
- `ruff`/`mypy`: NO DISPONIBLES en este entorno (solo quedan cachés `.ruff_cache`/`.mypy_cache`
  de sesiones previas, sin binarios instalados). Pendiente: crear venv del proyecto
  (autorizado por el usuario) e instalar ahí antes de validar estilo.

## Bloqueos activos

- Ninguno crítico. `ruff`/`mypy` ausentes (no bloquea funcionalidad, sí la validación de estilo).

## Límite de alcance documentado (Fase 3)

Solo se incorporaron JSON con la forma exacta `{binary, sha256, address_space,
symbol_value, original_name}` (3 entidades reales, en `analysis/functions/dossiers.json`).
Otros JSON de análisis con esquemas distintos (p. ej. `rea-takePicture-decompile.json`,
`silent-shutter-converter.json`, tablas IMX210/GPIO) NO están todavía en el grafo:
cada esquema heterogéneo necesitaría su propio extractor, y generalizar a ciegas
violaría el requisito de "no generar miles de relaciones irrelevantes". Pendiente:
añadir extractores específicos por esquema cuando se prioricen (candidatos naturales
para la Fase 4: GPIO fm3-gpio-shutter-mapping, EFCS capture-selector, WriteStill/SetImageWrited).

## Archivos nuevos de la Fase 4

- `docs/STATE.md` — estado breve con enlaces a fuentes canónicas.
- `docs/CORRECTIONS.md`, `docs/OPEN-QUESTIONS.md` — generados, regenerar con
  `export_corrections.py` tras cada `build_graph.py`.
- `scripts/knowledge/export_corrections.py` + `tests/knowledge/test_export_corrections.py`.
- `docs/history/CONTEXT-full-2026-10-18.md` (copia legible íntegra, indexada),
  `docs/history/CONTEXT.md.2026-10-18.bak` + `.sha256.orig` (respaldo binario-verificado).
- `CONTEXT.md` reescrito (116 líneas: S28–S30 + punteros).

## Fase 11 — auditoría independiente y corrección de defectos (2026-10-18)

Una auditoría del usuario (no de este mismo sistema) encontró defectos reales de
exactitud y de evaluación en lo entregado en las fases 1-10. Se corrigieron con
pruebas de regresión nuevas (39 tests totales, antes 23); cada fix documenta el
bug reproducido en el docstring/comentario del propio código.

**P1 — Exactitud del grafo (CERRADO):**
- `build_graph.py::build_function_graph` indexaba CALLS por nombre corto de método en
  un `dict` que se sobrescribía: si dos clases del mismo binario compartían nombre de
  método (p. ej. `A::run()` y `B::run()`), la llamada podía apuntar a la clase
  equivocada según el orden de inserción — el caso exacto que describió la auditoría.
  Fix: `qualified_name()` nuevo (conserva el calificador `ns::Clase::metodo`); se
  intenta primero resolución por nombre calificado exacto, y solo se cae a nombre
  corto cuando es ÚNICO en el binario; si es ambiguo, NO se genera arista (ni la
  correcta ni la incorrecta). Tests:
  `test_ambiguous_short_name_in_same_binary_is_discarded_not_misrouted`,
  `test_qualified_outgoing_name_disambiguates_same_short_name`.
- CORRECTS/SUPERSEDES: antes el status se detectaba buscando el vocabulario en toda
  la ventana de ±2 líneas, pudiendo atribuir un status de una oración vecina no
  relacionada. Ahora se busca primero en la línea del propio marcador. Además se
  separaron relaciones con enlace en la MISMA línea del marcador (evidencia directa)
  de relaciones cuyo enlace solo aparece en la ventana (proximidad, no demostración):
  estas últimas se marcan `CONFLICTO_PENDIENTE` y `extraction_method` distinto
  (`...window_candidate` vs `...same_line`), nunca heredan un status más fuerte por
  cercanía. Test: `test_link_only_in_window_is_candidate_not_verified`.

**P2 — Recuperación de contexto (PARCIAL, ver pendientes):**
- `ROOT = Path.cwd()` en los 6 scripts dependía del directorio desde el que se
  invocara el proceso. Nuevo `scripts/knowledge/_paths.py::find_root()`: busca hacia
  arriba desde cwd el marcador `CLAUDE.md`; cae a cwd si no lo encuentra (preserva el
  comportamiento de los fixtures de test, que deliberadamente no tienen marcador).
- `_budget_print` (router `ask`): un primer resultado más grande que el presupuesto se
  imprimía completo (la condición `shown > 0` lo eximía del recorte) — el presupuesto
  quedaba sin efecto real. Ahora se trunca también el primer bloque. Tests:
  `test_single_oversized_block_is_truncated_not_printed_whole`,
  `test_budget_print_never_exceeds_budget_across_multiple_blocks`.
- `cmd_exact`/rama `identifier` de `ask`: `rg --max-count N` limita POR ARCHIVO, no en
  total; con muchos archivos la salida combinada podía seguir siendo enorme. Ahora el
  límite se aplica en Python sobre el total de líneas combinadas (límite global real).
  Test: `test_global_limit_caps_total_lines_across_all_files`.
- `cmd_section` ganó `--subtree` (y la tool MCP `get_document_section` el parámetro
  `subtree`): por defecto devuelve solo el contenido PROPIO de la sección (hasta su
  primer sub-encabezado); con `--subtree` incluye todos los descendientes hasta el
  siguiente encabezado del mismo nivel o superior. Antes solo existía el modo "propio"
  sin forma de pedir el árbol completo. Tests: `test_default_section_excludes_children`,
  `test_subtree_includes_children_but_not_next_sibling`.
- `cmd_text` ganó `--offset` (paginación real sobre FTS5 `LIMIT`/`OFFSET`). Test:
  `test_offset_returns_different_page`.
- Nuevo comando `search.py freshness` + tool MCP `check_index_freshness`: compara el
  SHA-256 actual de cada doc contra la tabla `files` y reporta archivos
  modificados/añadidos/eliminados desde el último `index_docs.py`. Antes no había
  ninguna forma de saber si el índice estaba desincronizado. Tests en
  `tests/knowledge/test_freshness.py` (4 casos).
- `split_sections` (`index_docs.py`) descartaba TODO el texto anterior al primer
  encabezado Markdown. Ahora se conserva como sección `(preámbulo)` (nivel -1, nunca
  ancestro de un encabezado real en `build_tree`, para no corromper la jerarquía).
  Tests: `test_preamble_before_first_heading_is_preserved`,
  `test_preamble_does_not_become_parent_of_first_heading`.
- Límite MCP global: `mcp_server.py::_captured` ahora trunca cualquier salida a
  `MCP_MAX_CHARS = 20000` (antes una tool podía devolver una respuesta de tamaño
  arbitrario si el cliente pedía un `--limit`/`--budget` grande).
- **Pendiente real (no cerrado):** "ampliación de fragmentos por identificador" más
  allá de `--subtree`/`--offset` (p. ej. pedir N líneas de contexto arbitrarias
  alrededor de un `node_id`) no se implementó — el alcance actual cubre los dos casos
  concretos que pidió la auditoría (subárbol completo, paginación de `text`), no un
  mecanismo general de contexto configurable.

**P3 — Calidad del conocimiento (CERRADO en lo señalado):**
- `export_open_questions` generaba `docs/OPEN-QUESTIONS.md` buscando por TEXTO LIBRE
  las palabras NO_VERIFICADO/CONFLICTO_PENDIENTE en cualquier sección indexada: una
  sección que solo EXPLICA el vocabulario de status (sin ser una relación real del
  grafo) se contaba como pregunta abierta. Con el corpus real esto causaba 384 "filas"
  falsas. Ahora sale de la tabla `relations` (solo relaciones con ese status): tras
  rebuild completo, `docs/OPEN-QUESTIONS.md` pasó de 384 a **39 filas reales**.
  Test: `test_open_questions_ignores_sections_that_only_mention_the_word`.
- Mensaje de `cmd_claim`/`find_corrections` cuando no hay relaciones entrantes: antes
  decía "se mantiene como fuente vigente" (afirmación no demostrada por la ausencia de
  datos). Ahora aclara explícitamente que la ausencia de correcciones registradas NO
  demuestra vigencia.
- Tests de contradicción/corrección parcial/referencia histórica: ya existían
  parcialmente en `test_build_graph.py` (resolución de sesión, no auto-contaminación);
  se añadieron los de ambigüedad de nombre y candidata-vs-verificada arriba. No se
  amplió a un conjunto de "contradicciones narrativas" más allá de lo que el grafo
  determinista puede detectar (sigue siendo deliberadamente NO basado en inferencia de
  LLM: ver diseño original).

**P4 — Benchmarks (NO ABORDADO esta sesión):** sigue comparando presencia de
subcadena en la salida, no precisión de fuentes/rangos/evidencias, y no distingue
tokens estimados de tokens realmente consumidos por un agente real. Rediseñarlo es
trabajo no trivial (requiere una verdad de referencia estructurada, no solo una
subcadena esperada) y se deja pendiente explícitamente, no se improvisó una versión
a medias.

**P5 — Integración y memoria (PARCIAL):**
- Checkpoint actualizado con esta fase (ver `knowledge/checkpoints/`, el de esta
  sesión referencia fases 9-11 como completas, no pendientes).
- Verificación real de MCP/skills desde una sesión NUEVA de Claude Code o Codex sigue
  sin poder hacerse desde dentro de esta misma sesión (limitación estructural, igual
  que en la Fase 7).
- Extractores por esquema para GPIO/IMX210/OSAL/REA/Ghidra: NO implementados. Sigue
  siendo trabajo futuro (ver límite de Fase 3 arriba), ahora con la ambigüedad de
  nombres ya resuelta en el extractor existente para cuando se añadan.

## Próximo paso exacto

Pendiente real, en orden de impacto si se continúa:
1. Rediseño de `benchmark.py` (P4): verdad de referencia estructurada por consulta
   (fuente+rango+afirmación esperada, no una subcadena), comparando precisión real
   entre métodos con presupuestos equivalentes, y separando caracteres recuperados /
   tokens estimados (`chars/4`) / tokens reales consumidos (no medible sin integrar
   con un agente real que reporte su propio uso).
2. Extractores de grafo por esquema (GPIO/IMX210/OSAL/REA/Ghidra) — Fase 3/P5.
3. Verificación de descubrimiento de skills y MCP desde una sesión nueva real de
   Claude Code y de Codex (requiere que el usuario lo confirme fuera de esta sesión).
4. Si se prioriza, embeddings locales SOLO si un benchmark reproducible (tras el
   rediseño del punto 1) demuestra mejora sobre BM25.
